package mk.finki.ukim.mk.lab.service.impl;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.EventRepository;
import mk.finki.ukim.mk.lab.repository.EventRepositoryC;
import mk.finki.ukim.mk.lab.repository.LocationRepository;
import mk.finki.ukim.mk.lab.repository.LocationRepositoryC;
import mk.finki.ukim.mk.lab.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventServiceImpl implements EventService {

    //private final EventRepositoryC eventRepository;
    private final EventRepository eventRepository;
    //private final LocationRepositoryC locationRepository;
    private final LocationRepository locationRepository;

    public EventServiceImpl(EventRepository eventRepository, LocationRepository locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;
    }

    @Override
    public List<Event> listAll() {
        return eventRepository.findAll();
    }

    @Override
    public List<Event> searchEvents(String text) {
        //return eventRepository.searchEvents(text);
        return  eventRepository.searchEventsByDescription(text);
    }

    //
    public Event findById(Long eventId) {
        return eventRepository.findById(eventId)
                .orElseThrow(() -> new IllegalArgumentException("Настанот со ID " + eventId + " не постои"));
    }

    @Override
    public void saveEvent(String name, String description, Integer popularityScore, Long locationId) {
        //Location location = locationRepository.findById(locationId);
        Location location = locationRepository.findAllById(locationId);
        Event event = new Event(name, description, popularityScore, location);
        eventRepository.save(event);
    }


    @Override
    public void updateEvent(Long eventId, String name, String description, Integer popularityScore, Long locationId) {
        Event event = findById(eventId);

        //Location location = locationRepository.findById(locationId);
              //  .orElseThrow(() -> new IllegalArgumentException("Локацијата не постои"));

        Location location = locationRepository.findAllById(locationId);
        event.setName(name);
        event.setDescription(description);
        event.setPopularityScore(popularityScore);
        event.setLocation(location);
        eventRepository.save(event);
    }

    @Override
    public void deleteEvent(Long eventId) {
        eventRepository.deleteById(eventId);
    }

    @Override
    public List<Location> getAllLocations() {
        return locationRepository.findAll();
    }

}
