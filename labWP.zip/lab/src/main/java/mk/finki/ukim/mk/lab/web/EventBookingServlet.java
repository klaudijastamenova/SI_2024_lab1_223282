package mk.finki.ukim.mk.lab.web;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import mk.finki.ukim.mk.lab.model.EventBooking;
import mk.finki.ukim.mk.lab.service.EventBookingService;
import mk.finki.ukim.mk.lab.service.impl.EventServiceImpl;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;

import java.io.IOException;

@WebServlet(name = "EventBookingServlet",urlPatterns = "/eventBooking")

public class EventBookingServlet extends HttpServlet {

    private final EventServiceImpl eventService;

    private final SpringTemplateEngine springTemplateEngine;

    public EventBookingServlet(EventServiceImpl eventService, SpringTemplateEngine springTemplateEngine){
        this.eventService = eventService;
        this.springTemplateEngine = springTemplateEngine;
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String eventName = req.getParameter("eventName");
        String numTickets = req.getParameter("numTickets");

        if (eventName == null || numTickets == null) {
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "Event name or number of tickets is missing");
            return;
        }

        IWebExchange iWebExchange = JakartaServletWebApplication
                .buildApplication(req.getServletContext())
                .buildExchange(req,resp);
        WebContext context = new WebContext(iWebExchange);
        context.setVariable("eventName",eventName);
        context.setVariable("numTickets",numTickets);
        String attendeeName = req.getParameter("attendeeName");
        String clientIp = req.getRemoteAddr();

        context.setVariable("attendeeName", attendeeName);
        context.setVariable("clientIp", clientIp);

        springTemplateEngine.process("bookingConfirmation.html",context,resp.getWriter());
    }
}

