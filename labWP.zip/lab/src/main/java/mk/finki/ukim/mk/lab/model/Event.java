package mk.finki.ukim.mk.lab.model;

import jakarta.persistence.*;
import lombok.Data;
import mk.finki.ukim.mk.lab.repository.LocationRepositoryC;


@Entity
@Table(name = "events")
@Data
public class Event {

    //@ManyToOne(fetch = FetchType.LAZY)
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "location-id")
    private Location location;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private String name;
    private String description;
    private double popularityScore;

    public Event(String name, String description, double popularityScore) {
        this.id = (long) (Math.random() * 1000);
        this.name = name;
        this.description = description;
        this.popularityScore = popularityScore;
        this.location = getLocation();
    }
    public Event(String name, String description, double popularityScore, Location location) {
        this.id = (long) (Math.random() * 1000);
        this.name = name;
        this.description = description;
        this.popularityScore = popularityScore;
        this.location = location;
    }

    ///

    public Event() {
        this.id = (long) (Math.random() * 1000);
    }

    public Event(String name, String description, double popularityScore, String locationName) {
        this.id = (long) (Math.random() * 1000);
        this.name = name;
        this.description = description;
        this.popularityScore = popularityScore;
    }


    public void assignLocation(LocationRepositoryC locationRepository) {
        this.location = locationRepository.findAll().get(0);
    }

}
