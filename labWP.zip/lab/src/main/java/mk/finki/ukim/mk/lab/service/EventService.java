package mk.finki.ukim.mk.lab.service;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;

import java.util.List;

public interface EventService {
    List<Event> listAll();
    List<Event> searchEvents(String text);
    void saveEvent(String name, String description, Integer popularityScore, Long locationId);

    void updateEvent(Long eventId, String name, String description, Integer popularityScore, Long locationId);
    void deleteEvent(Long eventId);

    List<Location> getAllLocations();

    Event findById(Long eventId);


}
