package mk.finki.ukim.mk.lab.repository;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Repository
public class EventRepositoryC {

    private List<Event> eventList;
//    LocationRepository locationRepository;
//    List<Location> locations = locationRepository.findAll();
    Location location;

    public EventRepositoryC(){
        this.eventList = new ArrayList<>();

        eventList.add(new Event("Gallery Night", "Explore new art every week", 88.2, new Location(1L, "City Square", "Address 1", "200","Description 1")));
        eventList.add(new Event("Running Club", "Monthly race around the city", 74.3, new Location(5L, "Sport Center", "Address 2", "200","Description 2")));
        eventList.add(new Event("Symphony Night", "Orchestra playing classical pieces", 60.5, new Location(4L, "Symphony Hall", "Address 3", "200","Description 2")));
        eventList.add(new Event("Readers Circle", "Monthly book discussions", 50.8, new Location(2L, "Library", "Address 4", "200","Description 2")));
        eventList.add(new Event("Space Talks", "Insights on space missions", 77.5, new Location(3L, "City Park", "Address 5", "200","Description 2")));
        eventList.add(new Event("Winter Wonderland Festival", "A winter festival with ice sculptures", 59.9, new Location(5L, "Sport Center", "Address 2", "200","Description 2")));
        eventList.add(new Event("Mountain Adventure Marathon", "A thrilling marathon through mountainous terrain for adventure enthusiasts", 78.2, new Location(3L, "City Park", "Address 5", "200","Description 2")));
        eventList.add(new Event("Historical Drama", "Epic plays based on true events", 90.3,new Location(2L, "Library", "Address 4", "200","Description 2")));
        eventList.add(new Event("Musical Classics", "Beloved musicals live on stage", 45.6, new Location(4L, "Symphony Hall", "Address 3", "200","Description 2")));
        eventList.add(new Event("Theater Under Stars", "Outdoor performances of famous plays", 97.5, new Location(3L, "City Park", "Address 5", "200","Description 2") ));
    }

    public List<Event> findAll(){
        return eventList;
    }

    public Optional<Event> findById(Long id) {
    return eventList.stream().filter(event -> event.getId().equals(id)).findFirst();
    }

    public List<Event> searchEvents(String text) {
        return eventList.stream()
                .filter(event -> event.getName().contains(text) || event.getDescription().contains(text))
                .collect(Collectors.toList());
    }

    public void save(Event event) {
        eventList.add(event);
    }

    public void deleteById(Long id) {
        eventList.removeIf(event -> event.getId().equals(id));
    }


}
