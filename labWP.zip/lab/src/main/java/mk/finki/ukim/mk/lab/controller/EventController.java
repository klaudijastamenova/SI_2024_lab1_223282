package mk.finki.ukim.mk.lab.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.service.EventService;
import mk.finki.ukim.mk.lab.service.LocationService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/events")
public class EventController {

    @Autowired
    private final EventService eventService;
    @Autowired
    private final LocationService locationService;

    public EventController(EventService eventService, LocationService locationService) {
        this.eventService = eventService;
        this.locationService = locationService;
    }

    @GetMapping("/events")
    public String showEvents(Model model) {
        List<Event> events = eventService.listAll();
        List<Location> locations = locationService.findAll();

        model.addAttribute("events", events);
        model.addAttribute("locations", locations);

        return "listEvents";
    }

    @GetMapping
    public String getEventsPage(@RequestParam(required = false) String error, Model model){
        List<Event> events = eventService.listAll();
        List<Location> locations = locationService.findAll();
        model.addAttribute("events", events);
        model.addAttribute("locations", locations);
        model.addAttribute("error", error);
        return "listEvents";
    }
    @PostMapping("/add")
    public String saveEvent(@RequestParam String name,
                            @RequestParam String description,
                            @RequestParam double popularityScore,
                            @RequestParam Long locationId) {
        eventService.saveEvent(name, description, (int) popularityScore, locationId);
        return "redirect:/events";
    }


    @GetMapping("/edit/{eventId}")
    public String editEvent(@PathVariable Long eventId, Model model) {
        Event event = eventService.findById(eventId);
        List<Location> locations = locationService.findAll();

        model.addAttribute("event", event);
        model.addAttribute("locations", locations);

        return "editEvent";
    }


    @GetMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id) {
        eventService.deleteEvent(id);
        return "redirect:/events";
    }


//new
    @GetMapping("/events/new")
    public String showAddEventForm(Model model) {
        Event event = new Event();
        model.addAttribute("event", event);
        model.addAttribute("locations", locationService.findAll());
        return "add-event";
    }

    @GetMapping("/events/{id}")
    public String showEditEventForm(@PathVariable Long id, Model model) {
        Event event = eventService.findById(id);
        model.addAttribute("event", event);
        model.addAttribute("locations", locationService.findAll());
        return "add-event";
    }

    @PostMapping("/events/save")
    public String saveEvent(@ModelAttribute("event") Event event) {
        eventService.saveEvent(event.getName(), event.getDescription(), (int) event.getPopularityScore(), event.getId());  // Чување или уредување на настан
        return "redirect:/events";
    }


    @PostMapping("/save")
    public String updateEvent(@ModelAttribute Event event, @RequestParam Long locationId) {
        Location location = locationService.findById(locationId);
        if (location != null) {
            event.setLocation(location);
            eventService.saveEvent(event.getName(), event.getDescription(), (int) event.getPopularityScore(), event.getLocation().getId());  // Чување на настанот по уредувањето
            return "redirect:/events";
        } else {
            return "redirect:/events?error=Location not found";
        }
    }

   @GetMapping("/add")
    public String getAddEventPage(Model model) {
        List<Location> locations = locationService.findAll();
        model.addAttribute("locations", locations);
        return "add-event";
    }
}








