package mk.finki.ukim.mk.lab.repository;

import mk.finki.ukim.mk.lab.model.Location;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class LocationRepositoryC {
    private List<Location> locationList;

    public LocationRepositoryC() {
        this.locationList = new ArrayList<>();
        locationList.add(new Location(1L, "City Square","Address 1", "100","Outdoor concert"));
        locationList.add(new Location(2L, "Library","Address 2", "300", "Reading events"));
        locationList.add(new Location(3L, "City Park", "Address 3", "600", "HighSchool Athletics"));
        locationList.add(new Location(4L, "Symphony Hall", "Address 4", "200", "Classical music performances"));
        locationList.add(new Location(5L, "Sport Center", "Address 5", "150", "Swimming competition"));

    }
    public List<Location> findAll() {
        return locationList;
    }
    public Location findById(Long id) {
        return locationList.stream().filter(location -> location.getId().equals(id)).findFirst().orElse(null);
    }
}
